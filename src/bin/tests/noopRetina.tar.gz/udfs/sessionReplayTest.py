def nonOp(colName):
    return str(colName)
 