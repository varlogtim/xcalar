#!/usr/bin/python

# =map(concat(concat(pyExec(fixupDate,normalizeFriskDate,datestop),":"),timestop))
# stop and frisk dates come in several forms:
#
# " 7012014"
# "01012003"
# "8122005"
# "2006-9-1"
#
# stop and frisk times come in several forms:
#
# "   0" <- midnight
# " 301" <- 3:01am
# "0405" <- 4:05am
# "00:0" <- midnight
#


import sys

def hasDashes(dateIn):
    return (dateIn.find("-") != -1)

def hasColon(timeIn):
    return (timeIn.find(":") != -1)

def getFriskYear(dateIn):
    if (hasDashes(dateIn)):
        return dateIn[:4]
    return dateIn[-4:]

def getFriskMonth(dateIn):
    if (hasDashes(dateIn)):
        month = dateIn.split("-")[1]
    else:
        if len(dateIn) == 8:
            month = dateIn[0] + dateIn[1]
        else:
            month = dateIn[0]
    if len(month) == 1:
        month = "0" + month
    return month

def getFriskDay(dateIn):
    if (hasDashes(dateIn)):
        day = dateIn.split("-")[2]
    else:
        if len(dateIn) == 8:
            day = dateIn[2] + dateIn[3]
        else:
            day = dateIn[1] + dateIn[2]
    if len(day) == 1:
        day = "0" + day
    return day

def normalizeFriskDate(dateIn):
    date=dateIn.lstrip()
    date=date.strip()

    year=getFriskYear(date)
    month=getFriskMonth(date)
    day=getFriskDay(date)

    outputStr=year + month + day
    if (len(outputStr) != 8 or not outputStr.isdigit()):
        return ""

    return outputStr

def getFriskHour(time):
    if (hasColon(time)):
        hour = time.split(":")[0]
    elif (len(time) < 3):
        hour = "00"
    elif (len(time) == 3):
        hour = time[0]
    else:
        hour = time[0] + time[1]

    if (len(hour) == 1):
        hour = "0" + hour

    return hour

def getFriskMin(time):
    if (hasColon(time)):
        minute = time.split(":")[1]
    elif (len(time) < 3):
        minute = time
    elif (len(time) == 3):
        minute = time[1] + time[2]
    else:
        minute = time[2] + time[3]

    if (len(minute) == 1):
        minute = "0" + minute

    return minute

def normalizeFriskTime(timeIn):
    time=timeIn.lstrip()
    time=time.strip()

    hour=getFriskHour(time)
    minute=getFriskMin(time)

    outputStr=hour + minute
    if (len(outputStr) != 4 or not outputStr.isdigit()):
        return ""

    return outputStr

def getMayor(datetime):
    if (datetime < 201401010000):
        return "Michael Bloomberg"
    return "Bill de Blasio"

# daniels_v_NYC 2003 required logs
def preFloydRuling(datetime):
    if (datetime < 201308120000):
        return "1"
    else:
        return "0"

def main():
    outputStr = normalizeFriskDate(" 7012014");
    print outputStr
    outputStr = normalizeFriskDate("04052003");
    print outputStr
    outputStr = normalizeFriskDate("8122005");
    print outputStr
    outputStr = normalizeFriskDate("2006-9-1");
    print outputStr
    outputStr = normalizeFriskTime("   0");
    print outputStr
    outputStr = normalizeFriskTime(" 301");
    print outputStr
    outputStr = normalizeFriskTime("0405");
    print outputStr
    outputStr = normalizeFriskTime("23:59");
    print outputStr
    sys.exit(0)

if __name__ == "__main__":
    main()
