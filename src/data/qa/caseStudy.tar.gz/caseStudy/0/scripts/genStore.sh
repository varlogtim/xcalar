#! /bin/bash

if [ $# -ne 2 ]; then
    echo "Usage: $0 <path-to-addresses> <path-to-output>"
    exit 0
fi

addressFile=$1
output=$2
MaxNumStores=100

genRandIpAddrPrefix()
{
    ipAddrPrefix=""
    for ii in `seq 0 2`; do
        if [ $ii -gt 0 ]; then
            ipAddrPrefix="${ipAddrPrefix}."
        fi
        ipAddrPrefix="$ipAddrPrefix$(( RANDOM % 256 ))"
    done
    echo "$ipAddrPrefix"
}

if [ ! -e "$addressFile" ]; then
    echo "Could not find $addressFile"
    exit 1
fi

if [ -e "$output" ]; then
    echo "WARNING! $output already exists and will be overwritten. Do you wish to continue? [y/N]"
    read proceed
    if [ "$proceed" != 'y' -a "$proceed" != 'Y' ]; then
        exit 0
    fi
    rm "$output"
fi

touch "$output"
totalLines=`cat $addressFile | wc -l`
linesProcessed=0
storeNum=0

while read line; do
    storeNum=$(( $storeNum + 1 ))
    ipAddrPrefix=`genRandIpAddrPrefix`
    address="$line"
    echo -e "$storeNum\t$address\t$ipAddrPrefix" >> $output
    linesProcessed=$(( $linesProcessed + 1 ))
    echo "Processed $linesProcessed of $totalLines lines"
    if [ "$linesProcessed" -ge "$MaxNumStores" ]; then
        break
    fi
done <<< "`cat $addressFile`"



