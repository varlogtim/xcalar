#! /bin/bash

genRandMacAddr()
{
    local totalEntries=`cat $ouiFile | wc -l`
    local randEntry=$(( $RANDOM % $totalEntries + 1 ))
    local prefix=`sed "${randEntry}q;d" $ouiFile | cut -f 1`
    for ii in `seq 0 2`; do
        randOctet=$(( $RANDOM % 256 ))
        prefix="$prefix:`printf "%X" $randOctet`"
    done
    echo "$prefix"
}

genRandIpAddr()
{
    local totalEntries=`cat $storesFile | wc -l`
    local randEntry=$(( $RANDOM % $totalEntries + 1 ))
    local prefix=`sed "${randEntry}q;d" $storesFile | cut -f 3`
    local ipAddr="$prefix.$(( $RANDOM % 256 ))"
    echo "$ipAddr"
}

if [ $# -ne 4 ]; then
    echo "Usage $0 <ouiFile> <storesFile> <routerLog> <switchLog>"
    exit 0
fi

ouiFile=$1
storesFile=$2
routerLog=$3
switchLog=$4

if [ ! -e $ouiFile ]; then
    echo "Could not find $ouiFile"
    exit 1
fi

if [ ! -e $storesFile ]; then
    echo "Could not find $storesFile"
    exit 1
fi

if [ -e $routerLog ]; then
    echo "$routerLog already exists! Overwrite? [y/N]"
    read proceed
    if [ "$proceed" != 'y' -a "$proceed" != 'Y' ]; then
        exit 0
    fi
    rm $routerLog
fi

if [ -e $switchLog ]; then
    echo "$switchLog already exists! Overwrite? [y/N]"
    read proceed
    if [ "$proceed" != 'y' -a "$proceed" != 'Y' ]; then
        exit 0
    fi
    rm $switchLog
fi

touch $routerLog
touch $switchLog

NumRouters=10
NumSwitches=10
NumDevices=1000

for ii in `seq 0 $NumDevices`; do
    macAddr=`genRandMacAddr`
    ipAddr=`genRandIpAddr`
    routerNum=$(( $RANDOM % $NumRouters + 1 ))
    switchNum=$(( $RANDOM % $NumSwitches + 1 ))
    portNum=$(( $RANDOM % 65536 ))
    echo "$routerNum,$macAddr,$ipAddr" >> $routerLog
    echo "$switchNum,$macAddr,$portNum" >> $switchLog
    echo "Logging device $ii of $NumDevices"
done
