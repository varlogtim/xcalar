#! /bin/bash

if [ $# -ne 2 ]; then
    echo "Usage: $0 <path-to-oui> <path-to-output>"
    exit 0
fi

ouiFile=$1
output=$2
MaxNumLines=1000

if [ ! -e "$ouiFile" ]; then
    echo "Could not find $ouiFile"
    exit 1
fi

if [ -e "$output" ]; then
    echo "WARNING! $output already exists and will be overwritten. Do you wish to continue? [y/N]"
    read proceed
    if [ "$proceed" != 'y' -a "$proceed" != 'Y' ]; then
        exit 0
    fi
    rm "$output"
fi

touch "$output"
totalLines=`cat $ouiFile | grep "(hex)" | wc -l`
linesProcessed=0

while read line; do
    macAddr=`echo "$line" | cut -d \  -f 1 | sed -e 's/^\s*//' -e 's/\s*$//' -e 's/-/:/g'`
    organization=`echo "$line" | cut -d \) -f 2| sed -e 's/^\s*//' -e 's/\s*$//'`
    echo -e "$macAddr\t$organization" >> $output
    linesProcessed=$(( $linesProcessed + 1 ))
    echo "Processed $linesProcessed of $totalLines lines"
    if [ "$linesProcessed" -ge "$MaxNumLines" ]; then
        break
    fi
done <<< "`cat $ouiFile | grep \"(hex)\"`"



