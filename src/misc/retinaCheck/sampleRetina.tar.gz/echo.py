def echo(string):
    return string
